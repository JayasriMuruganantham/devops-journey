#!/bin/bash
n=1
while [ $n -le 5 ]
do
    echo "Iteration: $n"
    n=$((n+1))
done

