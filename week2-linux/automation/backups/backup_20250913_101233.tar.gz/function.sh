#!/bin/bash
greet() {
    echo "Hello, $1!"
}
greet "Jayasri"
greet "DevOps"

