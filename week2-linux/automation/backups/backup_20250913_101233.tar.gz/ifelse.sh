#!/bin/bash
count=10

if [ $count -gt 5 ]
then
    echo "Count is greater than 5"
else
    echo "Count is less or equal to 5"
fi

